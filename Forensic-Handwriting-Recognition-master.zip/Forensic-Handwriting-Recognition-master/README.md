# Handwriting-Comparison
Designed several Machine Learning methods to compare handwriting of words written by different and same writers. An accuracy of 98% was achieved on CEDAR Letter dataset. 
